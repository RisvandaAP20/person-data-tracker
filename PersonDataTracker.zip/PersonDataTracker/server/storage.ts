import { PersonData, SearchHistory, SavedSearch } from "@/lib/types";

export interface IStorage {
  // Person data
  getPersonData(name: string): Promise<PersonData | undefined>;
  savePersonData(name: string, data: PersonData): Promise<void>;
  
  // Search history
  getSearchHistory(): Promise<SearchHistory[]>;
  addSearchHistory(query: string): Promise<void>;
  clearSearchHistory(): Promise<void>;
  
  // Saved searches
  getSavedSearches(): Promise<SavedSearch[]>;
  addSavedSearch(name: string): Promise<void>;
  removeSavedSearch(id: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private personData: Map<string, PersonData>;
  private searchHistory: SearchHistory[];
  private savedSearches: SavedSearch[];
  private nextHistoryId: number;
  private nextSavedSearchId: number;
  
  constructor() {
    this.personData = new Map();
    this.searchHistory = [];
    this.savedSearches = [];
    this.nextHistoryId = 1;
    this.nextSavedSearchId = 1;
  }
  
  // Person data methods
  async getPersonData(name: string): Promise<PersonData | undefined> {
    const normalizedName = name.toLowerCase().trim();
    return this.personData.get(normalizedName);
  }
  
  async savePersonData(name: string, data: PersonData): Promise<void> {
    const normalizedName = name.toLowerCase().trim();
    this.personData.set(normalizedName, data);
  }
  
  // Search history methods
  async getSearchHistory(): Promise<SearchHistory[]> {
    // Return most recent searches first
    return [...this.searchHistory].reverse();
  }
  
  async addSearchHistory(query: string): Promise<void> {
    // Add search to history, limiting to 50 most recent
    const timestamp = new Date().toISOString();
    
    // Check if this query already exists, if so, update timestamp
    const existingIndex = this.searchHistory.findIndex(
      item => item.query.toLowerCase() === query.toLowerCase()
    );
    
    if (existingIndex !== -1) {
      // Remove existing entry
      this.searchHistory.splice(existingIndex, 1);
    }
    
    // Add new entry
    this.searchHistory.push({
      id: this.nextHistoryId++,
      query,
      timestamp
    });
    
    // Limit history to 50 items
    if (this.searchHistory.length > 50) {
      this.searchHistory.shift();
    }
  }
  
  async clearSearchHistory(): Promise<void> {
    this.searchHistory = [];
  }
  
  // Saved searches methods
  async getSavedSearches(): Promise<SavedSearch[]> {
    // Return most recent saved searches first
    return [...this.savedSearches].reverse();
  }
  
  async addSavedSearch(name: string): Promise<void> {
    // Check if this name already exists
    const existingIndex = this.savedSearches.findIndex(
      item => item.name.toLowerCase() === name.toLowerCase()
    );
    
    if (existingIndex !== -1) {
      // Update timestamp for existing entry
      this.savedSearches[existingIndex].timestamp = new Date().toISOString();
      return;
    }
    
    // Add new saved search
    this.savedSearches.push({
      id: this.nextSavedSearchId++,
      name,
      timestamp: new Date().toISOString()
    });
  }
  
  async removeSavedSearch(id: number): Promise<void> {
    const index = this.savedSearches.findIndex(item => item.id === id);
    
    if (index !== -1) {
      this.savedSearches.splice(index, 1);
    }
  }
}

export const storage = new MemStorage();
