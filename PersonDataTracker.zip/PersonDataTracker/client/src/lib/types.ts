// Source categories
export type ResultCategory = "all" | "social" | "professional" | "news" | "public";

// Base source interface
export interface Source {
  sourceName: string;
  category: Exclude<ResultCategory, "all">;
  profileUrl?: string;
  
  // Social media & professional fields
  username?: string;
  profileName?: string;
  profilePictureUrl?: string;
  title?: string;
  location?: string;
  description?: string;
  followers?: string;
  tags?: string[];
  stats?: {
    following?: string;
    followers?: string;
    posts?: string;
  };
  
  // News article fields
  publisher?: string;
  headline?: string;
  publishDate?: string;
  additionalInfo?: string;
  
  // Public records fields
  age?: string;
  previousAddresses?: string[];
  propertyRecords?: string;
  additionalRecords?: { 
    name: string;
    url?: string;
  }[];
}

// Person data returned from API
export interface PersonData {
  name: string;
  sources: Source[];
}

// Search history
export interface SearchHistory {
  id: number;
  query: string;
  timestamp: string;
}

// Saved search
export interface SavedSearch {
  id: number;
  name: string;
  timestamp: string;
}
