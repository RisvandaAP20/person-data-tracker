import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model from template (keeping it for compatibility)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Search history table
export const searchHistory = pgTable("search_history", {
  id: serial("id").primaryKey(),
  query: text("query").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const insertSearchHistorySchema = createInsertSchema(searchHistory).pick({
  query: true,
});

export type InsertSearchHistory = z.infer<typeof insertSearchHistorySchema>;
export type SearchHistory = typeof searchHistory.$inferSelect;

// Saved searches table
export const savedSearches = pgTable("saved_searches", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const insertSavedSearchSchema = createInsertSchema(savedSearches).pick({
  name: true,
});

export type InsertSavedSearch = z.infer<typeof insertSavedSearchSchema>;
export type SavedSearch = typeof savedSearches.$inferSelect;

// Source types (used for validation, not stored in DB)
export const sourceSchema = z.object({
  sourceName: z.string(),
  category: z.enum(["social", "professional", "news", "public"]),
  profileUrl: z.string().optional(),
  username: z.string().optional(),
  profileName: z.string().optional(),
  profilePictureUrl: z.string().optional(),
  title: z.string().optional(),
  location: z.string().optional(),
  description: z.string().optional(),
  followers: z.string().optional(),
  tags: z.array(z.string()).optional(),
  stats: z.object({
    following: z.string().optional(),
    followers: z.string().optional(),
    posts: z.string().optional(),
  }).optional(),
  publisher: z.string().optional(),
  headline: z.string().optional(),
  publishDate: z.string().optional(),
  additionalInfo: z.string().optional(),
  age: z.string().optional(),
  previousAddresses: z.array(z.string()).optional(),
  propertyRecords: z.string().optional(),
  additionalRecords: z.array(z.object({
    name: z.string(),
    url: z.string().optional(),
  })).optional(),
});

export const personDataSchema = z.object({
  name: z.string(),
  sources: z.array(sourceSchema),
});

export type Source = z.infer<typeof sourceSchema>;
export type PersonData = z.infer<typeof personDataSchema>;
