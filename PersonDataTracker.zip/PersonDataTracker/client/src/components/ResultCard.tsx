import { Card } from "@/components/ui/card";
import { Source } from "@/lib/types";
import { SiLinkedin, SiFacebook, SiInstagram } from "react-icons/si";
import { FileText, Gavel, Twitter } from "lucide-react";

interface ResultCardProps {
  source: Source;
  personName: string;
}

export default function ResultCard({ source, personName }: ResultCardProps) {
  // Helper to get the appropriate icon for the source
  const getSourceIcon = () => {
    switch (source.sourceName.toLowerCase()) {
      case "linkedin":
        return <SiLinkedin className="h-6 w-6 mr-2 text-blue-600" />;
      case "twitter":
      case "twitter/x":
        return <Twitter className="h-5 w-5 mr-2 text-black" />;
      case "facebook":
        return <SiFacebook className="h-6 w-6 mr-2 text-blue-600" />;
      case "instagram":
        return <SiInstagram className="h-6 w-6 mr-2 text-pink-600" />;
      case "news mention":
      case "news article":
        return <FileText className="h-5 w-5 mr-2 text-yellow-700" />;
      case "public records":
        return <Gavel className="h-5 w-5 mr-2 text-green-700" />;
      default:
        return <div className="h-6 w-6 mr-2 rounded-full bg-primary" />;
    }
  };

  // Helper to get the appropriate background color for the header
  const getHeaderBgColor = () => {
    switch (source.category) {
      case "social":
        return "bg-blue-50";
      case "professional":
        return "bg-blue-50";
      case "news":
        return "bg-yellow-50";
      case "public":
        return "bg-green-50";
      default:
        return "bg-gray-50";
    }
  };

  // Helper to get category description
  const getCategoryDescription = () => {
    switch (source.category) {
      case "social":
        return "Social Network";
      case "professional":
        return "Professional Network";
      case "news":
        return source.publisher || "News Source";
      case "public":
        return "Government Database";
      default:
        return "Information Source";
    }
  };

  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow">
      <div className={`p-4 border-b ${getHeaderBgColor()}`}>
        <div className="flex items-center">
          {getSourceIcon()}
          <h3 className="font-medium text-gray-800">{source.sourceName}</h3>
          <span className="ml-auto text-xs text-gray-500">{getCategoryDescription()}</span>
        </div>
      </div>
      <div className="p-4">
        {/* Profile Section - for social and professional */}
        {(source.category === "social" || source.category === "professional") && (
          <div className="flex items-start mb-4">
            {source.profilePictureUrl ? (
              <div className="w-12 h-12 rounded-full bg-gray-200 mr-3 flex items-center justify-center overflow-hidden">
                <span className="text-xl font-bold text-gray-500">
                  {personName.charAt(0)}
                </span>
              </div>
            ) : (
              <div className="w-12 h-12 rounded-full bg-gray-200 mr-3 flex items-center justify-center overflow-hidden">
                <span className="text-xl font-bold text-gray-500">
                  {personName.charAt(0)}
                </span>
              </div>
            )}
            <div>
              <h4 className="font-medium">
                {source.profileName || source.username || personName}
              </h4>
              {source.title && <p className="text-sm text-gray-600">{source.title}</p>}
              {source.location && <p className="text-sm text-gray-600">{source.location}</p>}
              {source.followers && <p className="text-xs text-gray-500">{source.followers} followers</p>}
            </div>
          </div>
        )}
        
        {/* Content Description */}
        {source.description && (
          <div className="text-sm text-gray-700 mb-3">
            <p>{source.description}</p>
            {source.additionalInfo && <p className="mt-2">{source.additionalInfo}</p>}
          </div>
        )}
        
        {/* Skills/Tags */}
        {source.tags && source.tags.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-3">
            {source.tags.map((tag, index) => (
              <span key={index} className="px-2 py-1 bg-gray-100 rounded-full text-xs text-gray-700">
                {tag}
              </span>
            ))}
          </div>
        )}
        
        {/* News Article Specific */}
        {source.category === "news" && source.publishDate && (
          <p className="text-xs text-gray-500 mb-3">Published: {source.publishDate}</p>
        )}
        
        {/* Public Records Specific */}
        {source.category === "public" && (
          <div className="grid grid-cols-2 gap-2 text-sm mb-3">
            {source.age && (
              <div>
                <p className="text-gray-500">Age</p>
                <p className="font-medium">{source.age}</p>
              </div>
            )}
            {source.location && (
              <div>
                <p className="text-gray-500">Location</p>
                <p className="font-medium">{source.location}</p>
              </div>
            )}
            {source.previousAddresses && source.previousAddresses.length > 0 && (
              <div>
                <p className="text-gray-500">Previous Addresses</p>
                {source.previousAddresses.map((address, idx) => (
                  <p key={idx} className="font-medium">{address}</p>
                ))}
              </div>
            )}
            {source.propertyRecords && (
              <div>
                <p className="text-gray-500">Property Records</p>
                <p className="font-medium">{source.propertyRecords}</p>
              </div>
            )}
          </div>
        )}
        
        {/* Social Media Stats */}
        {source.category === "social" && source.stats && (
          <div className="flex justify-between text-sm mb-3">
            {source.stats.following && (
              <span><b>{source.stats.following}</b> Following</span>
            )}
            {source.stats.followers && (
              <span><b>{source.stats.followers}</b> Followers</span>
            )}
            {source.stats.posts && (
              <span><b>{source.stats.posts}</b> Posts</span>
            )}
          </div>
        )}
        
        {/* View Full Profile Link */}
        {source.profileUrl && (
          <a href={source.profileUrl} target="_blank" rel="noopener noreferrer" className="text-primary text-sm hover:underline">
            {source.category === "news" ? "Read Full Article →" : "View Full Profile →"}
          </a>
        )}
      </div>
    </Card>
  );
}
