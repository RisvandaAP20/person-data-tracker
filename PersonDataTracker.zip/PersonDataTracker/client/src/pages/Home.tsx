import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import SearchSection from "@/components/SearchSection";
import ResultsSection from "@/components/ResultsSection";
import EmptyState from "@/components/EmptyState";
import LoadingState from "@/components/LoadingState";
import { PersonData } from "@/lib/types";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSources, setSelectedSources] = useState({
    social: true,
    professional: true,
    news: true,
    public: true,
  });
  
  const { data: searchResults, isLoading, refetch, isRefetching } = useQuery<PersonData | null>({
    queryKey: searchQuery ? [`/api/search?name=${encodeURIComponent(searchQuery)}`] : [],
    enabled: false,
  });

  const handleSearch = async (query: string, sources: typeof selectedSources) => {
    setSearchQuery(query);
    setSelectedSources(sources);
    refetch();
  };

  return (
    <main className="container mx-auto px-4 py-8">
      <SearchSection onSearch={handleSearch} />
      
      {isLoading || isRefetching ? (
        <LoadingState sources={selectedSources} />
      ) : searchResults ? (
        <ResultsSection personData={searchResults} />
      ) : (
        <EmptyState />
      )}
    </main>
  );
}
