import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

export default function Help() {
  return (
    <div className="container mx-auto px-4 py-8">
      <Card className="w-full max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle className="text-2xl font-bold">Help & FAQ</CardTitle>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-1">
              <AccordionTrigger>How does Person Data Finder work?</AccordionTrigger>
              <AccordionContent>
                Person Data Finder aggregates publicly available information from various online sources 
                based on the name you search. Our system queries multiple data sources including social 
                media platforms, professional networks, news articles, and public records to provide you 
                with a comprehensive overview of the person you're searching for.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-2">
              <AccordionTrigger>Is all of the information accurate?</AccordionTrigger>
              <AccordionContent>
                We strive to provide accurate information by sourcing from reputable platforms, but 
                we cannot guarantee 100% accuracy. The data we display is only as accurate as the 
                source it comes from. We recommend verifying critical information from multiple sources.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-3">
              <AccordionTrigger>How do I export search results?</AccordionTrigger>
              <AccordionContent>
                You can export your search results by clicking the "Export" button at the top of the 
                results section. This will download a file containing all the information found about 
                the person you searched for, organized by source.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-4">
              <AccordionTrigger>What sources do you search?</AccordionTrigger>
              <AccordionContent>
                We search across multiple sources including major social media platforms (LinkedIn, Twitter, 
                Facebook, Instagram), professional databases, news articles, and public records where available. 
                You can customize which sources to include in your search using the checkboxes on the search form.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-5">
              <AccordionTrigger>Is my search history saved?</AccordionTrigger>
              <AccordionContent>
                Yes, your recent searches are saved locally for your convenience. You can view your search 
                history on the History page and clear it at any time. We do not share your search history 
                with third parties.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-6">
              <AccordionTrigger>How do I get the most accurate results?</AccordionTrigger>
              <AccordionContent>
                For best results, use the full name of the person you're searching for. If the name is common, 
                try to add additional information you might know, such as their location or profession, to help 
                narrow down the results.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>
    </div>
  );
}
