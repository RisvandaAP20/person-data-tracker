import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import fetch from "node-fetch";
import cheerio from "cheerio";

export async function registerRoutes(app: Express): Promise<Server> {
  // Search API endpoint
  app.get("/api/search", async (req: Request, res: Response) => {
    try {
      const name = req.query.name as string;
      
      if (!name) {
        return res.status(400).json({ 
          message: "Name parameter is required" 
        });
      }
      
      // Save search to history
      await storage.addSearchHistory(name);
      
      // Fetch data from multiple sources
      const personData = await fetchPersonData(name);
      
      return res.json(personData);
    } catch (error) {
      console.error("Search error:", error);
      return res.status(500).json({ 
        message: "Error searching for person data" 
      });
    }
  });
  
  // Export data API endpoint
  app.get("/api/export", async (req: Request, res: Response) => {
    try {
      const name = req.query.name as string;
      
      if (!name) {
        return res.status(400).json({ 
          message: "Name parameter is required" 
        });
      }
      
      const personData = await fetchPersonData(name);
      
      // Set headers for download
      res.setHeader("Content-Type", "application/json");
      res.setHeader("Content-Disposition", `attachment; filename=${name.replace(/\s+/g, "_")}_data.json`);
      
      return res.json(personData);
    } catch (error) {
      console.error("Export error:", error);
      return res.status(500).json({ 
        message: "Error exporting person data" 
      });
    }
  });
  
  // Search history API endpoints
  app.get("/api/history", async (_req: Request, res: Response) => {
    try {
      const history = await storage.getSearchHistory();
      return res.json(history);
    } catch (error) {
      console.error("History fetch error:", error);
      return res.status(500).json({ 
        message: "Error fetching search history" 
      });
    }
  });
  
  app.delete("/api/history", async (_req: Request, res: Response) => {
    try {
      await storage.clearSearchHistory();
      return res.json({ 
        message: "Search history cleared successfully" 
      });
    } catch (error) {
      console.error("History clear error:", error);
      return res.status(500).json({ 
        message: "Error clearing search history" 
      });
    }
  });
  
  // Saved searches API endpoints
  app.post("/api/saved-searches", async (req: Request, res: Response) => {
    try {
      const { name } = req.body;
      
      if (!name) {
        return res.status(400).json({ 
          message: "Name parameter is required" 
        });
      }
      
      await storage.addSavedSearch(name);
      
      return res.json({ 
        message: "Search saved successfully" 
      });
    } catch (error) {
      console.error("Save search error:", error);
      return res.status(500).json({ 
        message: "Error saving search" 
      });
    }
  });
  
  app.get("/api/saved-searches", async (_req: Request, res: Response) => {
    try {
      const savedSearches = await storage.getSavedSearches();
      return res.json(savedSearches);
    } catch (error) {
      console.error("Saved searches fetch error:", error);
      return res.status(500).json({ 
        message: "Error fetching saved searches" 
      });
    }
  });

  const httpServer = createServer(app);
  
  return httpServer;
}

// Function to fetch person data from multiple sources
async function fetchPersonData(name: string) {
  try {
    // Normalize the name for searches
    const normalizedName = name.toLowerCase().trim();
    
    // Check if we have cached data for this person
    const cachedData = await storage.getPersonData(normalizedName);
    if (cachedData) {
      return cachedData;
    }
    
    // If no cached data, proceed with fetching
    const socialResults = await fetchSocialMediaData(name);
    const professionalResults = await fetchProfessionalData(name);
    const newsResults = await fetchNewsData(name);
    const publicResults = await fetchPublicRecordsData(name);
    
    // Combine all results
    const personData = {
      name,
      sources: [
        ...socialResults,
        ...professionalResults,
        ...newsResults,
        ...publicResults
      ]
    };
    
    // Cache the results
    await storage.savePersonData(normalizedName, personData);
    
    return personData;
  } catch (error) {
    console.error("Error fetching person data:", error);
    throw error;
  }
}

// Function to fetch social media data
async function fetchSocialMediaData(name: string) {
  // In a real implementation, this would interface with social media APIs
  // or use web scraping where permitted
  
  // For demonstration, simulate search results with realistic data structure
  // Will be replaced with actual API calls in a production environment
  const results = [];
  
  // Simulated LinkedIn result
  results.push({
    sourceName: "LinkedIn",
    category: "social",
    profileName: name,
    title: generateProfessionalTitle(),
    location: generateLocation(),
    description: `Professional with experience in ${generateProfessionalSkills().join(", ")}.`,
    tags: generateProfessionalSkills(),
    profileUrl: `https://linkedin.com/in/${name.toLowerCase().replace(/\s+/g, "-")}`,
  });
  
  // Simulated Twitter result
  results.push({
    sourceName: "Twitter/X",
    category: "social",
    username: `@${name.toLowerCase().replace(/\s+/g, "")}`,
    description: generateSocialBio(),
    stats: {
      following: Math.floor(Math.random() * 1000).toString(),
      followers: Math.floor(Math.random() * 5000).toString(),
      posts: Math.floor(Math.random() * 10000).toString(),
    },
    profileUrl: `https://twitter.com/${name.toLowerCase().replace(/\s+/g, "")}`,
  });
  
  // Simulated Facebook result
  results.push({
    sourceName: "Facebook",
    category: "social",
    profileName: name,
    location: generateLocation(),
    description: "Activity: Posts about professional events and personal interests.",
    profileUrl: `https://facebook.com/${name.toLowerCase().replace(/\s+/g, ".")}`,
  });
  
  // Simulated Instagram result
  results.push({
    sourceName: "Instagram",
    category: "social",
    username: `@${name.toLowerCase().replace(/\s+/g, ".")}.official`,
    profileName: name,
    description: "Content focus: Professional events, insights, travel, and lifestyle.",
    followers: Math.floor(Math.random() * 10000).toString(),
    profileUrl: `https://instagram.com/${name.toLowerCase().replace(/\s+/g, ".")}`,
  });
  
  return results;
}

// Function to fetch professional data
async function fetchProfessionalData(name: string) {
  // Simulated professional database results
  const results = [];
  
  results.push({
    sourceName: "Professional Directory",
    category: "professional",
    profileName: name,
    title: generateProfessionalTitle(),
    location: generateLocation(),
    description: `${Math.floor(Math.random() * 15) + 5}+ years of experience in ${generateIndustry()}.`,
    tags: generateProfessionalSkills(),
    profileUrl: "#",
  });
  
  return results;
}

// Function to fetch news data
async function fetchNewsData(name: string) {
  // Simulated news article search results
  const results = [];
  
  results.push({
    sourceName: "News Article",
    category: "news",
    headline: generateNewsHeadline(name),
    publisher: generatePublisher(),
    publishDate: generateRecentDate(),
    description: generateNewsContent(name),
    additionalInfo: `"${generateQuote()}" said ${name.split(" ")[0]}.`,
    profileUrl: "#",
  });
  
  return results;
}

// Function to fetch public records data
async function fetchPublicRecordsData(name: string) {
  // Simulated public records search results
  const results = [];
  
  results.push({
    sourceName: "Public Records",
    category: "public",
    age: (Math.floor(Math.random() * 40) + 25).toString(),
    location: generateLocation(),
    previousAddresses: [
      generateLocation(),
      generateLocation()
    ],
    propertyRecords: `Owner: ${generateAddress()}`,
    additionalRecords: [
      { name: "Voter Registration", url: "#" },
      { name: "Business Licenses", url: "#" },
      { name: "Court Records", url: "#" }
    ],
  });
  
  return results;
}

// Helper functions to generate realistic data
function generateProfessionalTitle() {
  const titles = [
    "Senior Developer", "Marketing Director", "Product Manager",
    "CEO", "CTO", "Sales Manager", "UX Designer", "Data Scientist"
  ];
  return titles[Math.floor(Math.random() * titles.length)];
}

function generateLocation() {
  const cities = [
    "San Francisco, CA", "New York, NY", "Chicago, IL", 
    "Austin, TX", "Seattle, WA", "Boston, MA"
  ];
  return cities[Math.floor(Math.random() * cities.length)];
}

function generateProfessionalSkills() {
  const allSkills = [
    "Marketing", "Leadership", "SEO", "Web Development", 
    "Data Analysis", "UX Design", "Project Management",
    "AI", "Machine Learning", "Sales", "Communication"
  ];
  
  const numSkills = Math.floor(Math.random() * 4) + 2;
  const selectedSkills = [];
  
  for (let i = 0; i < numSkills; i++) {
    const skill = allSkills[Math.floor(Math.random() * allSkills.length)];
    if (!selectedSkills.includes(skill)) {
      selectedSkills.push(skill);
    }
  }
  
  return selectedSkills;
}

function generateSocialBio() {
  const bios = [
    "Professional. Dog lover. Coffee enthusiast. Sharing thoughts on industry trends.",
    "Passionate about technology and innovation. Travel enthusiast. Foodie.",
    "Sharing insights and experiences from my professional journey. Book lover.",
    "Entrepreneur and tech enthusiast. Always learning new things."
  ];
  return bios[Math.floor(Math.random() * bios.length)];
}

function generateIndustry() {
  const industries = [
    "technology", "marketing", "finance", "healthcare", 
    "education", "retail", "manufacturing"
  ];
  return industries[Math.floor(Math.random() * industries.length)];
}

function generateNewsHeadline(name: string) {
  const headlines = [
    `${name.split(" ")[0]} Leads New Initiative at ${generateCompany()}`,
    `${generateCompany()} Announces Partnership, ${name} to Head Project`,
    `Industry Expert ${name} Speaks at ${generateConference()}`,
    `${name} Recognized for Excellence in ${generateIndustry()}`
  ];
  return headlines[Math.floor(Math.random() * headlines.length)];
}

function generateCompany() {
  const companies = [
    "TechCorp", "GlobalMedia", "InnovateTech", "FutureWorks", 
    "DataDynamics", "NexGen Solutions"
  ];
  return companies[Math.floor(Math.random() * companies.length)];
}

function generateConference() {
  const conferences = [
    "TechSummit 2023", "Global Innovation Conference",
    "Future of Technology Expo", "Industry Leaders Forum"
  ];
  return conferences[Math.floor(Math.random() * conferences.length)];
}

function generatePublisher() {
  const publishers = [
    "TechDaily", "BusinessInsider", "Industry Today",
    "Modern Enterprise", "Digital Trends"
  ];
  return publishers[Math.floor(Math.random() * publishers.length)];
}

function generateRecentDate() {
  const now = new Date();
  const pastDate = new Date(now.setMonth(now.getMonth() - Math.floor(Math.random() * 12)));
  return pastDate.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
}

function generateNewsContent(name: string) {
  const firstName = name.split(" ")[0];
  const contents = [
    `${generateCompany()} today announced a new initiative led by ${name}. The project aims to expand the company's reach in emerging markets.`,
    `In a recent development, ${name} has been appointed to lead the ${generateIndustry()} division at ${generateCompany()}.`,
    `Industry veteran ${name} shared insights on the future of ${generateIndustry()} at the ${generateConference()}.`
  ];
  return contents[Math.floor(Math.random() * contents.length)];
}

function generateQuote() {
  const quotes = [
    "We're focusing on innovation that delivers real value to our customers",
    "Our goal is to revolutionize the way people interact with technology",
    "This partnership represents a significant step forward for our industry",
    "We're committed to developing solutions that address real-world challenges"
  ];
  return quotes[Math.floor(Math.random() * quotes.length)];
}

function generateAddress() {
  const streets = ["Main St", "Oak Ave", "Maple Rd", "Park Blvd", "Market St"];
  const numbers = Math.floor(Math.random() * 999) + 1;
  return `${numbers} ${streets[Math.floor(Math.random() * streets.length)]}`;
}
