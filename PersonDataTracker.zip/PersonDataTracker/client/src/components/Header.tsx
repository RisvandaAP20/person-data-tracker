import { Link, useLocation } from "wouter";
import { UserSearch } from "lucide-react";

export default function Header() {
  const [location] = useLocation();
  
  return (
    <header className="bg-white shadow-sm">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center">
          <UserSearch className="text-primary text-3xl mr-2" />
          <h1 className="text-xl font-bold text-gray-800">Person Data Finder</h1>
        </div>
        <nav>
          <ul className="flex space-x-4">
            <li>
              <Link 
                href="/" 
                className={`${
                  location === "/" ? "text-primary" : "text-gray-600 hover:text-primary"
                }`}
              >
                Home
              </Link>
            </li>
            <li>
              <Link 
                href="/history" 
                className={`${
                  location === "/history" ? "text-primary" : "text-gray-600 hover:text-primary"
                }`}
              >
                History
              </Link>
            </li>
            <li>
              <Link 
                href="/help" 
                className={`${
                  location === "/help" ? "text-primary" : "text-gray-600 hover:text-primary"
                }`}
              >
                Help
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
}
