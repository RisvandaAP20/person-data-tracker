import { useState, useEffect, FormEvent } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { useLocation } from "wouter";
import { SearchHistory } from "@/lib/types";

interface SearchSectionProps {
  onSearch: (query: string, sources: {
    social: boolean;
    professional: boolean;
    news: boolean;
    public: boolean;
  }) => void;
}

export default function SearchSection({ onSearch }: SearchSectionProps) {
  const [location] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [sources, setSources] = useState({
    social: true,
    professional: true,
    news: true,
    public: true,
  });

  const { data: recentSearches } = useQuery<SearchHistory[]>({
    queryKey: ["/api/history"],
  });

  useEffect(() => {
    // Check for URL query param
    const urlParams = new URLSearchParams(window.location.search);
    const queryParam = urlParams.get("q");
    
    if (queryParam) {
      setSearchQuery(queryParam);
      handleSearch(queryParam);
    }
  }, [location]);

  const handleSearch = (query: string = searchQuery) => {
    if (query.trim()) {
      onSearch(query.trim(), sources);
    }
  };

  const handleSourceChange = (sourceKey: keyof typeof sources) => {
    setSources({
      ...sources,
      [sourceKey]: !sources[sourceKey],
    });
  };

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    handleSearch();
  };

  const handleRecentSearch = (query: string) => {
    setSearchQuery(query);
    handleSearch(query);
  };

  return (
    <section className="max-w-3xl mx-auto mb-8">
      <Card className="mb-4">
        <CardContent className="pt-6">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Find Person Data</h2>
          <p className="text-gray-600 mb-6">
            Enter a name to automatically search and compile information from multiple public sources.
          </p>
          
          <form onSubmit={handleSubmit} className="mb-4">
            <div className="relative">
              <Input
                type="text"
                placeholder="Enter full name (e.g., John Smith)"
                className="w-full px-4 py-6 pr-12 text-gray-700"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Button 
                type="submit" 
                className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-primary text-white p-2 rounded-full hover:bg-blue-600 transition-colors"
              >
                <Search className="h-5 w-5" />
              </Button>
            </div>
            
            <div className="flex flex-wrap gap-3 mt-4">
              <label className="flex items-center cursor-pointer">
                <Checkbox 
                  checked={sources.social}
                  onCheckedChange={() => handleSourceChange("social")}
                  className="h-5 w-5"
                />
                <span className="ml-2 text-gray-700">Social Media</span>
              </label>
              <label className="flex items-center cursor-pointer">
                <Checkbox 
                  checked={sources.professional}
                  onCheckedChange={() => handleSourceChange("professional")}
                  className="h-5 w-5"
                />
                <span className="ml-2 text-gray-700">Professional</span>
              </label>
              <label className="flex items-center cursor-pointer">
                <Checkbox 
                  checked={sources.news}
                  onCheckedChange={() => handleSourceChange("news")}
                  className="h-5 w-5"
                />
                <span className="ml-2 text-gray-700">News Articles</span>
              </label>
              <label className="flex items-center cursor-pointer">
                <Checkbox 
                  checked={sources.public}
                  onCheckedChange={() => handleSourceChange("public")}
                  className="h-5 w-5"
                />
                <span className="ml-2 text-gray-700">Public Records</span>
              </label>
            </div>
          </form>
          
          <div className="flex items-center justify-between text-sm text-gray-500 mt-4">
            <p>All data is gathered from publicly available sources</p>
            <a href="/help" className="text-primary hover:underline">Advanced Search Options</a>
          </div>
        </CardContent>
      </Card>
      
      {recentSearches && recentSearches.length > 0 && (
        <Card className="bg-white rounded-lg shadow-sm">
          <CardContent className="p-4">
            <h3 className="text-sm font-medium text-gray-700 mb-2">Recent Searches</h3>
            <div className="flex flex-wrap gap-2">
              {recentSearches.slice(0, 5).map((item) => (
                <Button
                  key={item.id}
                  variant="ghost"
                  className="px-3 py-1 h-auto bg-gray-100 text-gray-700 rounded-full text-sm hover:bg-gray-200"
                  onClick={() => handleRecentSearch(item.query)}
                >
                  {item.query}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </section>
  );
}
