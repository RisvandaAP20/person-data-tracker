import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, Bookmark } from "lucide-react";
import { PersonData, ResultCategory, Source } from "@/lib/types";
import ResultCard from "@/components/ResultCard";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface ResultsSectionProps {
  personData: PersonData;
}

export default function ResultsSection({ personData }: ResultsSectionProps) {
  const [activeTab, setActiveTab] = useState<ResultCategory>("all");
  const { toast } = useToast();
  
  // Create counts by category
  const counts = {
    all: personData.sources.length,
    social: personData.sources.filter(s => s.category === "social").length,
    professional: personData.sources.filter(s => s.category === "professional").length,
    news: personData.sources.filter(s => s.category === "news").length,
    public: personData.sources.filter(s => s.category === "public").length,
  };
  
  const filteredResults = activeTab === "all" 
    ? personData.sources 
    : personData.sources.filter(source => source.category === activeTab);
  
  const handleExport = async () => {
    try {
      const response = await fetch(`/api/export?name=${encodeURIComponent(personData.name)}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });
      
      if (!response.ok) {
        throw new Error("Failed to export data");
      }
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.style.display = "none";
      a.href = url;
      a.download = `${personData.name.replace(/\s+/g, "_")}_data.json`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      
      toast({
        title: "Export Successful",
        description: "The data has been exported successfully.",
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "There was an error exporting the data. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  const handleSave = async () => {
    try {
      await apiRequest("POST", "/api/saved-searches", { name: personData.name });
      
      toast({
        title: "Search Saved",
        description: "This search has been saved to your history.",
      });
    } catch (error) {
      toast({
        title: "Save Failed",
        description: "There was an error saving this search. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  return (
    <section className="max-w-6xl mx-auto">
      {/* Results Tabs */}
      <div className="bg-white rounded-t-lg shadow-sm border-b">
        <div className="flex overflow-x-auto">
          <button 
            className={`flex-shrink-0 px-6 py-3 font-medium ${
              activeTab === "all" ? "text-primary border-b-2 border-primary" : "text-gray-500 hover:text-gray-700"
            }`}
            onClick={() => setActiveTab("all")}
          >
            All Results 
            <span className={`ml-1 ${activeTab === "all" ? "bg-primary text-white" : "bg-gray-200 text-gray-700"} text-xs px-2 py-0.5 rounded-full`}>
              {counts.all}
            </span>
          </button>
          <button 
            className={`flex-shrink-0 px-6 py-3 font-medium ${
              activeTab === "social" ? "text-primary border-b-2 border-primary" : "text-gray-500 hover:text-gray-700"
            }`}
            onClick={() => setActiveTab("social")}
          >
            Social Media 
            <span className={`ml-1 ${activeTab === "social" ? "bg-primary text-white" : "bg-gray-200 text-gray-700"} text-xs px-2 py-0.5 rounded-full`}>
              {counts.social}
            </span>
          </button>
          <button 
            className={`flex-shrink-0 px-6 py-3 font-medium ${
              activeTab === "professional" ? "text-primary border-b-2 border-primary" : "text-gray-500 hover:text-gray-700"
            }`}
            onClick={() => setActiveTab("professional")}
          >
            Professional 
            <span className={`ml-1 ${activeTab === "professional" ? "bg-primary text-white" : "bg-gray-200 text-gray-700"} text-xs px-2 py-0.5 rounded-full`}>
              {counts.professional}
            </span>
          </button>
          <button 
            className={`flex-shrink-0 px-6 py-3 font-medium ${
              activeTab === "news" ? "text-primary border-b-2 border-primary" : "text-gray-500 hover:text-gray-700"
            }`}
            onClick={() => setActiveTab("news")}
          >
            News 
            <span className={`ml-1 ${activeTab === "news" ? "bg-primary text-white" : "bg-gray-200 text-gray-700"} text-xs px-2 py-0.5 rounded-full`}>
              {counts.news}
            </span>
          </button>
          <button 
            className={`flex-shrink-0 px-6 py-3 font-medium ${
              activeTab === "public" ? "text-primary border-b-2 border-primary" : "text-gray-500 hover:text-gray-700"
            }`}
            onClick={() => setActiveTab("public")}
          >
            Public Records 
            <span className={`ml-1 ${activeTab === "public" ? "bg-primary text-white" : "bg-gray-200 text-gray-700"} text-xs px-2 py-0.5 rounded-full`}>
              {counts.public}
            </span>
          </button>
        </div>
      </div>
      
      {/* Search summary */}
      <div className="bg-white px-6 py-4 border-b flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-gray-800">{personData.name}</h2>
          <p className="text-sm text-gray-500">
            Found {counts.all} results from {Object.keys(counts).filter(k => k !== "all" && counts[k as ResultCategory] > 0).length} sources
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            className="flex items-center gap-1"
            onClick={handleExport}
          >
            <Download className="h-4 w-4" /> Export
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="flex items-center gap-1"
            onClick={handleSave}
          >
            <Bookmark className="h-4 w-4" /> Save
          </Button>
        </div>
      </div>
      
      {/* Search results grid */}
      <Card className="rounded-b-lg shadow-md">
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredResults.map((source: Source, index: number) => (
              <ResultCard key={`${source.sourceName}-${index}`} source={source} personName={personData.name} />
            ))}
          </div>
          
          {filteredResults.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-500">No results found for this category. Try selecting a different category.</p>
            </div>
          )}
        </div>
      </Card>
    </section>
  );
}
