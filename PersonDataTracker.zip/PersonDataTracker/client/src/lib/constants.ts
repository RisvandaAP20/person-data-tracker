import { ResultCategory } from "./types";

// API endpoints
export const API_ENDPOINTS = {
  SEARCH: "/api/search",
  HISTORY: "/api/history",
  EXPORT: "/api/export",
  SAVED_SEARCHES: "/api/saved-searches",
};

// Labels for result categories
export const CATEGORY_LABELS: Record<ResultCategory, string> = {
  all: "All Results",
  social: "Social Media",
  professional: "Professional",
  news: "News",
  public: "Public Records",
};

// Source logos and icons
export const SOURCE_LOGOS = {
  linkedin: "https://upload.wikimedia.org/wikipedia/commons/c/ca/LinkedIn_logo_initials.png",
  twitter: "https://about.twitter.com/content/dam/about-twitter/x/brand-toolkit/logo-black.png.twimg.1920.png",
  facebook: "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b8/2021_Facebook_icon.svg/800px-2021_Facebook_icon.svg.png",
  instagram: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/Instagram_icon.png/600px-Instagram_icon.png",
};

// Search suggestions
export const SEARCH_SUGGESTIONS = [
  "Elon Musk",
  "Bill Gates",
  "Mark Zuckerberg",
  "Tim Cook",
  "Sundar Pichai",
];
