import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Globe, Briefcase, FileText, GavelIcon } from "lucide-react";

interface LoadingStateProps {
  sources: {
    social: boolean;
    professional: boolean;
    news: boolean;
    public: boolean;
  };
}

export default function LoadingState({ sources }: LoadingStateProps) {
  // Generate random progress values for visual feedback
  const socialProgress = sources.social ? Math.floor(Math.random() * 60) + 40 : 0;
  const professionalProgress = sources.professional ? Math.floor(Math.random() * 60) + 30 : 0;
  const newsProgress = sources.news ? Math.floor(Math.random() * 40) + 20 : 0;
  const publicProgress = sources.public ? Math.floor(Math.random() * 30) + 10 : 0;
  
  return (
    <section className="max-w-6xl mx-auto mt-8">
      <Card className="p-6">
        <div className="flex items-center justify-center mb-6">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary"></div>
          <p className="ml-3 text-lg font-medium text-gray-700">Searching multiple sources...</p>
        </div>
        
        <div className="space-y-4">
          {sources.social && (
            <div className="flex items-center">
              <Globe className="text-gray-400 h-5 w-5 mr-2" />
              <div className="w-full">
                <Progress value={socialProgress} className="h-2 bg-blue-100" />
                <p className="text-xs text-gray-500 mt-1">Searching social media profiles ({socialProgress}%)</p>
              </div>
            </div>
          )}
          
          {sources.professional && (
            <div className="flex items-center">
              <Briefcase className="text-gray-400 h-5 w-5 mr-2" />
              <div className="w-full">
                <Progress value={professionalProgress} className="h-2 bg-blue-100" />
                <p className="text-xs text-gray-500 mt-1">Scanning professional networks ({professionalProgress}%)</p>
              </div>
            </div>
          )}
          
          {sources.news && (
            <div className="flex items-center">
              <FileText className="text-gray-400 h-5 w-5 mr-2" />
              <div className="w-full">
                <Progress value={newsProgress} className="h-2 bg-blue-100" />
                <p className="text-xs text-gray-500 mt-1">Searching news articles ({newsProgress}%)</p>
              </div>
            </div>
          )}
          
          {sources.public && (
            <div className="flex items-center">
              <GavelIcon className="text-gray-400 h-5 w-5 mr-2" />
              <div className="w-full">
                <Progress value={publicProgress} className="h-2 bg-blue-100" />
                <p className="text-xs text-gray-500 mt-1">Checking public records ({publicProgress}%)</p>
              </div>
            </div>
          )}
        </div>
        
        {/* Skeleton loading cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
          {Array(3).fill(0).map((_, i) => (
            <div key={i} className="border rounded-lg overflow-hidden">
              <div className="p-4 border-b bg-gray-50">
                <div className="flex items-center">
                  <div className="h-6 w-6 rounded mr-2 bg-gray-200 animate-pulse"></div>
                  <div className="h-4 w-24 rounded bg-gray-200 animate-pulse"></div>
                  <div className="h-3 w-32 rounded ml-auto bg-gray-200 animate-pulse"></div>
                </div>
              </div>
              <div className="p-4">
                <div className="flex items-start mb-4">
                  <div className="h-12 w-12 rounded-full mr-3 bg-gray-200 animate-pulse"></div>
                  <div className="space-y-2 flex-1">
                    <div className="h-4 w-32 rounded bg-gray-200 animate-pulse"></div>
                    <div className="h-3 w-40 rounded bg-gray-200 animate-pulse"></div>
                    <div className="h-3 w-24 rounded bg-gray-200 animate-pulse"></div>
                  </div>
                </div>
                <div className="space-y-2 mb-4">
                  <div className="h-3 w-full rounded bg-gray-200 animate-pulse"></div>
                  <div className="h-3 w-full rounded bg-gray-200 animate-pulse"></div>
                  <div className="h-3 w-2/3 rounded bg-gray-200 animate-pulse"></div>
                </div>
                <div className="flex space-x-2 mb-3">
                  <div className="h-6 w-16 rounded-full bg-gray-200 animate-pulse"></div>
                  <div className="h-6 w-20 rounded-full bg-gray-200 animate-pulse"></div>
                  <div className="h-6 w-12 rounded-full bg-gray-200 animate-pulse"></div>
                </div>
                <div className="h-4 w-32 rounded bg-gray-200 animate-pulse"></div>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </section>
  );
}
