import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { SearchHistory } from "@/lib/types";
import { useLocation } from "wouter";

export default function History() {
  const { data: searchHistory, isLoading } = useQuery<SearchHistory[]>({
    queryKey: ["/api/history"],
  });
  
  const { toast } = useToast();
  const [, navigate] = useLocation();

  const handleRepeatSearch = (query: string) => {
    navigate(`/?q=${encodeURIComponent(query)}`);
  };

  const handleClearHistory = async () => {
    try {
      await fetch("/api/history", {
        method: "DELETE",
        credentials: "include",
      });
      
      toast({
        title: "History cleared",
        description: "Your search history has been cleared successfully.",
      });
      
      // Invalidate and refetch
      queryClient.invalidateQueries({ queryKey: ["/api/history"] });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to clear history. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <Card className="w-full max-w-4xl mx-auto">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-2xl font-bold">Search History</CardTitle>
          <Button 
            variant="outline" 
            size="sm"
            onClick={handleClearHistory}
            disabled={!searchHistory || searchHistory.length === 0}
          >
            Clear History
          </Button>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center p-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : !searchHistory || searchHistory.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <p>You have no search history yet.</p>
              <Button 
                variant="link" 
                onClick={() => navigate("/")}
                className="mt-2"
              >
                Go to search
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {searchHistory.map((item) => (
                <div 
                  key={item.id} 
                  className="flex items-center justify-between border-b pb-4"
                >
                  <div>
                    <h3 className="font-medium">{item.query}</h3>
                    <p className="text-sm text-gray-500">
                      {new Date(item.timestamp).toLocaleString()}
                    </p>
                  </div>
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => handleRepeatSearch(item.query)}
                  >
                    Search Again
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
