import { Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

interface EmptyStateProps {
  suggestions?: string[];
}

export default function EmptyState({ suggestions = [
  "Famous entrepreneurs",
  "Business leaders",
  "Industry experts"
] }: EmptyStateProps) {
  
  return (
    <section className="max-w-3xl mx-auto mt-8">
      <Card className="p-8 text-center">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-50 text-primary mb-4">
          <Search className="h-8 w-8" />
        </div>
        <h2 className="text-xl font-bold text-gray-800 mb-2">No Search Results Yet</h2>
        <p className="text-gray-600 mb-6">
          Enter a person's name in the search box above to find information from multiple sources.
        </p>
        <div className="flex flex-col items-center space-y-4">
          <p className="text-sm text-gray-500">Try searching for:</p>
          <div className="flex flex-wrap justify-center gap-2">
            {suggestions.map((suggestion, index) => (
              <Button
                key={index}
                variant="outline"
                className="px-4 py-2 h-auto bg-gray-100 text-gray-700 rounded-full text-sm hover:bg-gray-200 border-0"
                onClick={() => {
                  const searchInput = document.querySelector('input[type="text"]') as HTMLInputElement;
                  if (searchInput) {
                    searchInput.value = suggestion;
                    searchInput.form?.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
                  }
                }}
              >
                {suggestion}
              </Button>
            ))}
          </div>
        </div>
      </Card>
    </section>
  );
}
